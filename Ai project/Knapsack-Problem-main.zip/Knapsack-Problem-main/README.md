# Knapsack problem.
### Solving the knapsack problem using the Genetic Algorithm

#### Types of the knapsack problem:
- 0-1 Knapsack problem.
- Unbounded Knapsack problem.
